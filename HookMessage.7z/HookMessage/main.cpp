﻿#include "Windows.h"


HWND hWnd;
HHOOK hHook{ NULL };
WORD prevKey;
enum Keys
{
	ShiftKey = 16,
	Capital = 20,
};

WNDCLASS RegisWindow(HINSTANCE hInst);
void CreateWindows();
LRESULT CALLBACK WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK keyboard_hook(int code, WPARAM wParam, LPARAM lParam);
WORD ConvertAlphaToUniKey(WORD prevKey, DWORD vkCode);
INT WINAPI WinMain(HINSTANCE hInst, HINSTANCE prevInst, LPSTR lpCmdLine, INT nCmdShow)
{
	WNDCLASS wc;
	MSG msg;
	wc = RegisWindow(hInst);
	CreateWindows();
	ShowWindow(hWnd, nCmdShow);
	UpdateWindow(hWnd);
	while (GetMessage(&msg, 0, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return 0;

}

WNDCLASS RegisWindow(HINSTANCE hInst)
{
	WNDCLASS wc;

	wc = { 0 };
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = WindowProc;
	wc.hInstance = hInst;
	wc.hbrBackground = CreateSolidBrush(RGB(168, 231, 240));
	wc.lpszClassName = L"HookMessage";

	if (!RegisterClass(&wc))
	{
		MessageBox(NULL, L"Window Registration Failed!!!", L"Error", MB_OK);
	}
	return wc;
}

LRESULT CALLBACK WindowProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	hHook = SetWindowsHookEx(WH_KEYBOARD_LL, keyboard_hook, NULL, 0);
	if (hHook == NULL) {
		MessageBox(NULL, L"Keyboard hook failed!", L"Alert", MB_OK);
	}
	switch (msg)
	{
	case WM_CLOSE:
		DestroyWindow(hWnd);
		break;
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, msg, wParam, lParam);
	}
	return 0;
}

void CreateWindows()
{

	hWnd = CreateWindowW(L"HookMessage", L"HOOK Message", WS_OVERLAPPEDWINDOW | WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT,
		700, 500, 0, 0, 0, 0);
	HWND hResult = CreateWindowW(L"static", L"Message", WS_TABSTOP | WS_CHILD | WS_VISIBLE | WS_BORDER | SS_LEFT,
		30, 80, 233, 40, hWnd, 0, 0, 0);
	HWND hTextBox = CreateWindowW(L"edit", L"", WS_TABSTOP | WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL | ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL,
		30, 100, 250, 100, hWnd, 0, 0, 0);

}



int shift_active() {
	return GetKeyState(VK_LSHIFT) < 0 || GetKeyState(VK_RSHIFT) < 0;
}

int capital_active() {
	return (GetKeyState(VK_CAPITAL) & 1) == 1;
}

LRESULT CALLBACK keyboard_hook(int code, WPARAM wParam, LPARAM lParam)
{
	if (wParam == WM_KEYDOWN && code > 0)
	{
		KBDLLHOOKSTRUCT* kbdStruct = (KBDLLHOOKSTRUCT*)lParam;
		KEYBDINPUT kb = { 0 };
		INPUT Input = { 0 };
		if (kbdStruct->vkCode == VK_SPACE)
		{
			prevKey = NULL;
			CallNextHookEx(hHook, code, wParam, lParam);
		}
		
		if (prevKey == NULL) {
			CallNextHookEx(hHook, code, wParam, lParam);
		}
		else
		{
			prevKey = ConvertAlphaToUniKey(prevKey, kbdStruct->vkCode);
			kb.wScan = prevKey;
			kb.dwFlags = KEYEVENTF_UNICODE;
			Input.type = INPUT_KEYBOARD;
			Input.ki = kb;
			SendInput(1, &Input, sizeof(Input));
		}


		
		

	}
	
	
	return CallNextHookEx(hHook, code, wParam, lParam);
}

WORD ConvertAlphaToUniKey(WORD prevKey, DWORD vkCode)
{
	switch (prevKey)
	{
	case 0x41://a
	{
		switch (vkCode)
		{
		case 0x41://â
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x00C2;
		}
		case 0x57://ă
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x0102;
		}
		case 0x53://á
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x0102;
		}
		case 0x46://à
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x0102;
		}
		case 0x4a://ạ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x0102;
		}
		case 0x52://ả
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x0102;
		}
		case 0x58://ã
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x0102;
		}
		}
	}
	case 0x00C2://â
	{
		switch (vkCode)
		{
		case 0x53://ấ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EA5;
		}
		case 0x46://ầ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EA7;
		}
		case 0x4a://ậ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EAD;
		}
		case 0x52://ẩ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EA9;
		}
		case 0x58://ẫ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EAB;
		}
		}
	}
	case 0x0102://ă
	{
		switch (vkCode)
		{
		case 0x53://ắ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EAF;
		}
		case 0x46://ằ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EB1;
		}
		case 0x4a://ặ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EB7;
		}
		case 0x52://ẳ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EB3;
		}
		case 0x58://ẵ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EB7;
		}
		}
	}
	case 0x44://d
	{
		if (vkCode == 0x44)
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x0111;
		}

	}
	case 0x45://e
	{
		switch (vkCode)
		{
		case 0x45://ê
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x00EA;
		}
		case 0x53://é
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x00E9;
		}
		case 0x46://è
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x00E8;
		}
		case 0x5e://ẻ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EBB;
		}
		case 0x4a://ẹ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EB9;
		}
		case 0x58://ẽ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EBD;
		}
		}	
	}
	case 0x00EA://ê
	{
		switch (vkCode)
		{
		case 0x53://ế
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EBF;
		}
		case 0x46://ề
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EC1;
		}
		case 0x5e://ể
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EC3;
		}
		case 0x4a://ệ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EC7;
		}
		case 0x58://ễ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EC5;
		}
		}
	}
	case 0x49://i
	{
		switch (vkCode)
		{
		case 0x53://í
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x00ED;
		}
		case 0x46://ì
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x00EC;
		}
		case 0x5e://ỉ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EC9;
		}
		case 0x4a://ị
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1ECB;
		}
		case 0x58://ĩ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x0129;
		}
		}
	}
	case 0x4f://o
	{
		switch (vkCode)
		{
		case 0x4f://ô
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x00F4;
		}
		case 0x57://ơ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x01A1;
		}
		case 0x53://ó
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x000F3;
		}
		case 0x46://ò
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x0102;
		}
		case 0x5e://ỏ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1ECF;
		}
		case 0x4a://ọ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1ECD;
		}
		case 0x58://õ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x00F5;
		}
		}
	}
	case 0x00F4://ô
	{
		switch (vkCode)
		{
		case 0x53://ố
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x00ED;
		}
		case 0x46://ồ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x00EC;
		}
		case 0x5e://ổ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EC9;
		}
		case 0x4a://ộ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1ECB;
		}
		case 0x58://ỗ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x0129;
		}
		}
	}
	case 0x01A1://ơ
	{
		switch (vkCode)
		{
		case 0x53://ớ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EDB;
		}
		case 0x46://ờ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EDD;
		}
		case 0x5e://ở
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EDF;
		}
		case 0x4a://ợ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EE3;
		}
		case 0x58://ỡ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EE1;
		}
		}
	}
	case 0x55:
	{
		switch (vkCode)
		{
		case 0x55://ư
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x01B0;
		}
		case 0x53://ú
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x00FA;
		}
		case 0x46://ù
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x00F9;
		}
		case 0x5e://ủ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EE7;
		}
		case 0x4a://ụ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EE5;
		}
		case 0x58://ũ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x0169;
		}
		}
	}
	case 0x01B0://ư
	{
		switch (vkCode)
		{
		case 0x53://ứ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EE9;
		}
		case 0x46://ừ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EEB;
		}
		case 0x5e://ử
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EED;
		}
		case 0x4a://ự
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EF1;
		}
		case 0x58://ữ
		{
			keybd_event(VK_BACK, 0, 0, 0);
			return 0x1EEF;
		}
		}
	}
	default:
		break;
	}
}